# Overview

This is a computer help and remote support service landing page for a business located in Orhei, Moldova. The project consists of two distinct applications: a static HTML/CSS/JS multilingual landing page (deployed at the root) and a modern React/TypeScript application (in the client directory) built with Vite and shadcn/ui components.

The static landing page serves as the main marketing site with sections for services, pricing, remote support features, FAQ, and contact information. It includes comprehensive internationalization support for English, Russian, and Romanian languages. The React application appears to be a separate admin or dashboard interface that's currently minimal but set up with a full component library and modern tooling.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Static Landing Page (Root Level)**
- Built with vanilla HTML5, CSS3, and ES6+ JavaScript
- Mobile-first responsive design using CSS custom properties
- Modular JavaScript architecture with translation system
- Critical CSS inlined for performance optimization
- Font Awesome 6 icons and Inter font from Google Fonts

**React Application (Client Directory)**
- React 18 with TypeScript and Vite as the build tool
- shadcn/ui component library with Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- Wouter for client-side routing
- TanStack Query for server state management
- React Hook Form with Zod validation

## Internationalization (i18n)

The static landing page implements a custom translation system that:
- Loads JSON translation files dynamically based on user preference
- Persists language selection in localStorage
- Supports English, Russian, and Romanian languages
- Updates page content and HTML lang attribute dynamically

## Database and Backend

**Database Layer**
- Drizzle ORM configured for PostgreSQL
- Database connection through Neon Database serverless
- Schema defined in TypeScript with Zod validation
- User table with username/password authentication

**Express Server**
- Node.js/Express backend with TypeScript
- ESM module system
- Request logging middleware
- Error handling middleware
- Session management with connect-pg-simple
- Development and production build configurations

## Build and Development

**Development Workflow**
- Vite dev server with HMR for React application
- Express server with middleware mode for development
- TypeScript compilation with path aliases
- PostCSS with Tailwind CSS processing

**Production Build**
- Vite builds client application to dist/public
- esbuild bundles server code to dist/
- Static assets served from built client directory

## Form Integration

The contact form integrates with submit-form.com external service:
- Endpoint: https://submit-form.com/CmEGDF1k9
- Includes honeypot spam protection with 'company' field
- Hidden 'formName' field for form identification
- Client-side validation with user feedback

## SEO and Performance

**SEO Optimization**
- Complete meta tags including Open Graph and Twitter Cards
- JSON-LD structured data for LocalBusiness
- Canonical URLs and proper heading hierarchy
- Semantic HTML5 markup with landmark elements

**Performance Features**
- Critical CSS inlining for above-the-fold content
- Image preloading for hero section
- Lazy loading for non-critical images
- Font preconnection and optimized loading

# External Dependencies

## Core Technologies
- **React 18** - Frontend framework for client application
- **TypeScript** - Type safety across frontend and backend
- **Express.js** - Backend web framework
- **Vite** - Build tool and development server
- **Node.js** - Server runtime environment

## UI and Styling
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Component library built on Radix UI
- **Radix UI** - Unstyled, accessible UI primitives
- **Lucide React** - Icon library
- **Font Awesome 6** - Icon library for static site
- **Google Fonts (Inter)** - Typography

## Database and ORM
- **Drizzle ORM** - TypeScript ORM for PostgreSQL
- **Neon Database** - Serverless PostgreSQL hosting
- **connect-pg-simple** - PostgreSQL session store

## State Management and Forms
- **TanStack Query** - Server state management
- **React Hook Form** - Form library with validation
- **Zod** - Runtime type validation
- **Hookform Resolvers** - Integration between forms and validation

## Development and Build Tools
- **ESBuild** - JavaScript bundler for server code
- **PostCSS** - CSS processing
- **Autoprefixer** - CSS vendor prefixing
- **TypeScript** - Static type checking

## External Services
- **submit-form.com** - Form submission handling service
- **Google Fonts API** - Web font delivery
- **Font Awesome CDN** - Icon delivery
- **Replit Static Deployment** - Hosting platform

## Utility Libraries
- **class-variance-authority** - CSS class composition
- **clsx** - Conditional CSS classes
- **date-fns** - Date manipulation
- **vaul** - Drawer component library
- **cmdk** - Command palette component