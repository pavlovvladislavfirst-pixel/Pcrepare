(function() {
    'use strict';
    
    // Translation data
    let translations = {};
    
    // Current language
    let currentLanguage = localStorage.getItem('preferred-language') || (navigator.language||'en').slice(0,2);
    if(!['en','ru','ro'].includes(currentLanguage)) currentLanguage='en';

    
    // Load translations
    async function loadTranslations() {
        try {
            const response = await fetch(`i18n/${currentLanguage}.json`);
            if (response.ok) {
                translations = await response.json();
            } else {
                console.warn(`Failed to load translations for ${currentLanguage}`);
                // Fallback to English if current language fails
                if (currentLanguage !== 'en') {
                    const fallbackResponse = await fetch('i18n/en.json');
                    if (fallbackResponse.ok) {
                        translations = await fallbackResponse.json();
                    }
                }
            }
        } catch (error) {
            console.error('Error loading translations:', error);
        }
    }
    
    // Update language on page
    function updateLanguage(lang) {
        currentLanguage = lang;
        localStorage.setItem('preferred-language', lang);
        
        // Update HTML lang attribute
        document.documentElement.lang = lang;
        
        // Load new translations and update content
        loadTranslations().then(() => {
            updateContent();
        });
        
        // Update language selector
        const languageSelect = document.getElementById('language-select');
        if (languageSelect) {
            languageSelect.value = lang;
        }
    }
    
    // Update all translatable content
    function updateContent() {
        // Update elements with data-i18n attributes
        const elements = document.querySelectorAll('[data-i18n]');
        elements.forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                element.textContent = translations[key];
            }
        });
        
        // Update placeholder attributes
        const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
        placeholderElements.forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });
    }
    
    // Mobile menu functionality
    function initMobileMenu() {
        const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuToggle && mobileMenu) {
            mobileMenuToggle.addEventListener('click', function() {
                const isOpen = !mobileMenu.classList.contains('hidden');
                
                if (isOpen) {
                    mobileMenu.classList.add('hidden');
                    mobileMenuToggle.setAttribute('aria-expanded', 'false');
                } else {
                    mobileMenu.classList.remove('hidden');
                    mobileMenuToggle.setAttribute('aria-expanded', 'true');
                }
            });
            
            // Close mobile menu when clicking on links
            const mobileLinks = mobileMenu.querySelectorAll('a');
            mobileLinks.forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                    mobileMenuToggle.setAttribute('aria-expanded', 'false');
                });
            });
            
            // Close mobile menu with ESC key for accessibility
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && !mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                    mobileMenuToggle.setAttribute('aria-expanded', 'false');
                    // Return focus to toggle button for better UX
                    mobileMenuToggle.focus();
                }
            });
        }
    }
    
    // FAQ toggle functionality
    function initFAQ() {
        const faqToggles = document.querySelectorAll('[data-faq-toggle]');
        faqToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-faq-toggle');
                const content = document.getElementById(targetId + '-content');
                const icon = this.querySelector('i');
                const isOpen = !content.classList.contains('hidden');
                
                if (isOpen) {
                    content.classList.add('hidden');
                    this.setAttribute('aria-expanded', 'false');
                } else {
                    content.classList.remove('hidden');
                    this.setAttribute('aria-expanded', 'true');
                }
            });
        });
    }
    
    // Form validation
    function validateField(field) {
        const errorDiv = field.parentNode.querySelector('.error-message');
        let isValid = true;
        let message = '';
        
        // Check if required field is empty
        if (field.hasAttribute('required') && !field.value.trim()) {
            isValid = false;
            message = 'This field is required';
        }
        
        // Email validation
        if (field.type === 'email' && field.value && !isValidEmail(field.value)) {
            isValid = false;
            message = 'Please enter a valid email address';
        }
        
        // Show or hide error
        if (!isValid) {
            showFieldError(field, errorDiv, message);
        } else {
            clearFieldError(field, errorDiv);
        }
        
        return isValid;
    }
    
    function showFieldError(field, errorDiv, message) {
        field.classList.add('form-error');
        field.classList.remove('form-success');
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.classList.remove('hidden');
        }
    }
    
    function clearFieldError(field, errorDiv) {
        field.classList.remove('form-error');
        field.classList.add('form-success');
        if (errorDiv) {
            errorDiv.classList.add('hidden');
        }
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Form submission
    function initContactForm() {
        const contactForm = document.getElementById('contact-form');
        const formSuccess = document.getElementById('form-success');
        const formError = document.getElementById('form-error');
        
        if (!contactForm) return;
        
        // Real-time validation
        const requiredFields = contactForm.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            field.addEventListener('blur', () => validateField(field));
            field.addEventListener('input', () => {
                if (field.classList.contains('form-error')) {
                    validateField(field);
                }
            });
        });
        
        // Form submission
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            // Validate all required fields
            let isValid = true;
            requiredFields.forEach(field => {
                if (!validateField(field)) {
                    isValid = false;
                }
            });
            
            if (!isValid) {
                return;
            }
            
            // Show loading state
            const submitButton = contactForm.querySelector('button[type="submit"]');
            const originalText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.classList.add('loading');
            submitButton.textContent = 'Sending...';
            
            // Hide previous status messages
            formSuccess.classList.add('hidden');
            formError.classList.add('hidden');
            
            // Submit form data
            const formData = new FormData(contactForm);
            
            fetch(contactForm.action, {
                method: 'POST',
                body: formData,
                mode: 'no-cors' // Required for submit-form.com
            })
            .then(() => {
                // Show success message (optimistic since no-cors doesn't return response)
                formSuccess.classList.remove('hidden');
                contactForm.reset();
                
                // Clear form validation states
                const fields = contactForm.querySelectorAll('input, select, textarea');
                fields.forEach(field => {
                    field.classList.remove('form-error', 'form-success');
                });
                
                // Scroll to success message
                formSuccess.scrollIntoView({ behavior: 'smooth', block: 'center' });
            })
            .catch(() => {
                // Show error message
                formError.classList.remove('hidden');
                formError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            })
            .finally(() => {
                // Reset button state
                submitButton.disabled = false;
                submitButton.classList.remove('loading');
                submitButton.textContent = originalText;
            });
        });
    }
    
    // Smooth scrolling for anchor links
    function initSmoothScrolling() {
        const anchorLinks = document.querySelectorAll('a[href^="#"]');
        anchorLinks.forEach(link => {
            link.addEventListener('click', function(event) {
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    // Special handling for skip links - use default behavior for accessibility
                    if (this.classList.contains('skip-link')) {
                        // Let default browser behavior handle skip links
                        // Focus the target element for screen readers
                        targetElement.focus();
                        return;
                    }
                    
                    event.preventDefault();
                    
                    const headerHeight = document.querySelector('.header').offsetHeight;
                    const targetPosition = targetElement.offsetTop - headerHeight - 20;
                    
                    // Update URL hash without triggering default behavior
                    history.pushState(null, null, targetId);
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    const mobileMenu = document.getElementById('mobile-menu');
                    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
                    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                        mobileMenuToggle.setAttribute('aria-expanded', 'false');
                    }
                }
            });
        });
    }
    
    // Lazy loading for images
    function initLazyLoading() {
        const images = document.querySelectorAll('img[loading="lazy"]');
        
        if ('IntersectionObserver' in window && images.length > 0) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.classList.remove('loading');
                        observer.unobserve(img);
                    }
                });
            });
            
            images.forEach(img => {
                img.classList.add('loading');
                imageObserver.observe(img);
            });
        }
    }
    
    // Accessibility improvements
    function initAccessibility() {
        // Add focus visible polyfill for better keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                document.body.classList.add('user-is-tabbing');
            }
        });
        
        document.addEventListener('mousedown', function() {
            document.body.classList.remove('user-is-tabbing');
        });
        
        // Announce language changes to screen readers
        const languageSelect = document.getElementById('language-select');
        if (languageSelect) {
            languageSelect.addEventListener('change', function() {
                const announcement = document.createElement('div');
                announcement.setAttribute('aria-live', 'polite');
                announcement.setAttribute('aria-atomic', 'true');
                announcement.className = 'sr-only';
                announcement.textContent = `Language changed to ${this.options[this.selectedIndex].text}`;
                document.body.appendChild(announcement);
                
                setTimeout(() => {
                    document.body.removeChild(announcement);
                }, 1000);
                
                updateLanguage(this.value);
            });
        }
    }
    
    // Performance monitoring
    function initPerformanceMonitoring() {
        // Log performance metrics when page loads
        window.addEventListener('load', function() {
            if ('performance' in window) {
                const perfData = performance.timing;
                const loadTime = perfData.loadEventEnd - perfData.navigationStart;
                console.log(`Page load time: ${loadTime}ms`);
                
                // Log Largest Contentful Paint if available
                if ('PerformanceObserver' in window) {
                    const observer = new PerformanceObserver((list) => {
                        const entries = list.getEntries();
                        const lastEntry = entries[entries.length - 1];
                        console.log(`LCP: ${lastEntry.startTime.toFixed(2)}ms`);
                    });
                    
                    try {
                        observer.observe({ entryTypes: ['largest-contentful-paint'] });
                    } catch (e) {
                        // LCP not supported
                    }
                }
            }
        });
    }
    
    // Initialize everything when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        // Load initial translations and update content
        loadTranslations().then(() => {
            updateContent();
        });
        
        // Initialize all functionality
        initMobileMenu();
        initFAQ();
        initContactForm();
        initSmoothScrolling();
        initLazyLoading();
        initAccessibility();
        initPerformanceMonitoring();
        
        // Set initial language
        const languageSelect = document.getElementById('language-select');
        if (languageSelect) {
            languageSelect.value = currentLanguage;
        }
        
        console.log('Computer Help landing page initialized successfully');
    });
    
})();
