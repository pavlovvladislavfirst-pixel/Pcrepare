
const LANGS=['ru','ro','en'];
const LSKEY='lang';

function detectLang(){
  const stored = localStorage.getItem(LSKEY);
  if(stored && LANGS.includes(stored)) return stored;
  const n = (navigator.language||'').toLowerCase();
  if(n.startsWith('ru')) return 'ru';
  if(n.startsWith('ro')) return 'ro';
  return 'en';
}

async function loadDict(lang){
  const res = await fetch(`i18n/${lang}.json`, {cache:'no-store'});
  return await res.json();
}

function applyDict(dict){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(dict[key]) el.textContent = dict[key];
  });
  document.title = dict.site_title || document.title;
  const ld = document.getElementById('ld-localbusiness');
  if(ld){
    try {
      const data = JSON.parse(ld.textContent);
      if(dict.city) data.areaServed = dict.city;
      ld.textContent = JSON.stringify(data);
    } catch(e){}
  }
}

async function setLang(lang){
  const dict = await loadDict(lang);
  applyDict(dict);
  localStorage.setItem(LSKEY, lang);
  document.documentElement.lang = lang;
}

function initLang(){
  const current = detectLang();
  setLang(current);
  document.querySelectorAll('button[data-lang]').forEach(b=>{
    b.addEventListener('click', ()=> setLang(b.dataset.lang));
  });
}

function initForm(){
  const form = document.getElementById('lead-form');
  const msg = document.getElementById('form-msg');
  if(!form) return;
  form.addEventListener('submit', async (e)=>{
    // Honeypot
    if(form.company && form.company.value){ e.preventDefault(); return; }
    // Enhance submit with fetch
    e.preventDefault();
    const data = new FormData(form);
    msg.textContent = '...';
    try {
      const res = await fetch(form.action, { method:'POST', body:data, mode:'no-cors' });
      // submit-form.com often uses no-cors; show optimistic success
      msg.textContent = '✓ Спасибо! Мы свяжемся с вами в ближайшее время.';
      form.reset();
    } catch(err){
      msg.style.color = '#fca5a5';
      msg.textContent = 'Ошибка отправки. Попробуйте ещё раз или свяжитесь через мессенджер.';
    }
  });
}

function initYear(){
  const y = document.getElementById('year');
  if(y) y.textContent = new Date().getFullYear();
}

document.addEventListener('DOMContentLoaded', ()=>{
  initLang(); initForm(); initYear();
});
