# Remote PC Help Landing (RU/RO/EN)

Static, mobile-first landing tailored for Orhei, Moldova.
- Language switcher (RU/RO/EN) via `/i18n/*.json`
- Contact form posts to https://submit-form.com/CmEGDF1k9 (with honeypot)
- Local preview in Replit: Python http.server
- Deployment target: Replit Static Deployment

## Replace hero
Swap `assets/hero.jpg` with your real hero image (keep the same filename to avoid code changes).

## Run locally (Replit)
Just press **Run**. It starts `python3 -m http.server $PORT` and serves `index.html`.

## Files
- `index.html` — page structure and sections
- `styles.css` — minimal clean styles
- `main.js` — i18n + form enhancement
- `i18n/{ru,ro,en}.json` — copy for each language
- `.replit` & `replit.nix` — preview configuration
